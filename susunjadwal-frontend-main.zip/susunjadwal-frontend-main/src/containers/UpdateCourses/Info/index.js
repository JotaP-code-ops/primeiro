import { Link } from "@chakra-ui/react";
import styled from "styled-components";
import React from "react";

const MANUAL_VIDEO_URL =
  "https://drive.google.com/file/d/1hXwLpzcttDeeuTKN-fs49lroW6UnssaM/view";

const Info = ({ mode }) => (
  <InfoContainer className="info-container" mode={mode}>
    <Question>Apa itu Update Matkul?</Question>
    <Answer>
      Update Matkul adalah fitur yang membolehkan penggunanya untuk memperbarui
      jadwal kuliah dari program studi masing-masing sesuai dengan jadwal di
      SIAK-NG.
    </Answer>
    <Question>Kenapa perlu Update Matkul?</Question>
    <Answer>
      SusunJadwal tidak bekerjasama dengan pihak UI. Sehingga, SusunJadwal perlu
      untuk mengumpulkan data jadwal kuliah mahasiswa dari seluruh program studi
      agar SusunJadwal dapat digunakan.
    </Answer>
    <Question>
      Apakah akun SSO saya aman setelah melakukan Update Matkul?
    </Question>
    <Answer>
      100% aman, karena kami sama sekali tidak menyimpan <em>credentials</em>{" "}
      kalian di sistem kami.
    </Answer>
    <Question>
      Saya masih ragu, apakah saya dapat mempelajari SusunJadwal?
    </Question>
    <Answer>
      Kami suka semangat keingintahuanmu! Untuk mempelajari bagaimana
      SusunJadwal bekerja, kamu dapat lihat di{" "}
      <Link
        _hover={{ color: "black" }}
        rel="noopener noreferrer"
        href={MANUAL_VIDEO_URL}
        target="_blank"
      >
        <u>video</u>
      </Link>{" "}
      ini.
    </Answer>
  </InfoContainer>
);

export default Info;

const InfoContainer = styled.ul`
  padding: 2rem 1.5rem 2rem calc(1rem + 24px);
  background-color: ${({ mode }) => (mode === "light" ? "#f8f8f8" : "#222222")};
  color: ${({ mode }) => (mode === "light" ? "" : "#D0D0D0")};
  border: 1px solid #5038bc;
  font-family: "Poppins";
  border-radius: 0.8rem;
  position: relative;
  z-index: 4;

  @media (min-width: 900px) {
    padding: 3rem 2.5rem 3rem calc(2rem + 24px);
  }
`;

const Question = styled.li`
  font-weight: 600;
  margin-bottom: 0.5rem;
`;

const Answer = styled.p`
  margin-bottom: 1rem;
`;
